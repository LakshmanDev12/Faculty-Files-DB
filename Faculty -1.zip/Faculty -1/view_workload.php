<?php include('database.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Faculty Course Load</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
    }

    body {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* A warm gradient */
  min-height: 100vh;

  justify-content: center;
 
  padding: 40px;
}

    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 28px;
    }

    table {
      width: 90%;
      margin: 0 auto;
      border-collapse: collapse;
      background-color: #fff;
      box-shadow: 0 6px 12px rgba(0,0,0,0.1);
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 16px;
      text-align: center;
      font-size: 16px;
    }

    th {
      background-color: #3366ff;
      color: #fff;
      font-weight: 600;
    }

    tr:nth-child(even) {
      background-color: #f2f4fc;
    }

    img {
      width: 100px;
      height: auto;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    @media (max-width: 768px) {
      table, th, td {
        font-size: 14px;
      }

      img {
        width: 80px;
      }
    }
  </style>
</head>
<body>

<h2>Faculty Course Load</h2>

<?php
$query = "SELECT f.id, f.name AS faculty_name, COUNT(fc.course_id) AS total_courses, f.photo_data
          FROM faculty f
          LEFT JOIN faculty_course fc ON f.id = fc.faculty_id
          GROUP BY f.id, f.name, f.photo_data";

$result = pg_query($connection, $query);

echo "<table>
<tr><th>Faculty Name</th><th>Total Courses</th><th>Photo</th></tr>";

while ($row = pg_fetch_assoc($result)) {
    $image = pg_unescape_bytea($row['photo_data']);
    $image_base64 = base64_encode($image);

    echo "<tr>
            <td>{$row['faculty_name']}</td>
            <td>{$row['total_courses']}</td>
            <td><img src='data:image/jpeg;base64,{$image_base64}' alt='Faculty Photo'></td>
          </tr>";
}

echo "</table>";
?>

</body>
</html>
