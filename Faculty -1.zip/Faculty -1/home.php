<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Faculty Entry System</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', sans-serif;
    }

    body {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* A warm gradient */
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
}

    .container {
      max-width: 700px;
      width: 100%;
      text-align: center;
    }

    h1 {
      font-size: 28px;
      margin-bottom: 30px;
      color: #333;
    }

    .box {
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.05);
      padding: 30px 40px;
      margin-bottom: 30px;
    }

    .box h2 {
      font-size: 20px;
      color: #444;
      margin-bottom: 20px;
    }

    .button-group a {
      display: block;
      text-decoration: none;
      padding: 12px 20px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 16px;
      transition: transform 0.2s ease, background-color 0.3s ease;
      margin: 12px 0;
    }

    /* Action buttons (Add/Assign) */
    .action-button {
      background-color: #3366ff;
      color: #ffffff;
    }

    .action-button:hover {
      background-color: #2a55e0;
      transform: translateY(-2px);
    }

    /* View buttons */
    .view-button {
      background-color: #ffffff;
      color: #3366ff;
      border: 2px solid #3366ff;
    }

    .view-button:hover {
      background-color: #eaf0ff;
      transform: translateY(-2px);
    }

    @media (max-width: 600px) {
      .box {
        padding: 20px;
      }

      h1 {
        font-size: 24px;
      }

      .box h2 {
        font-size: 18px;
      }

      .button-group a {
        font-size: 15px;
        padding: 10px 16px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to Faculty Entry Website</h1>

    <!-- Add/Assign Box -->
    <div class="box">
      <h2>Manage Faculty</h2>
      <div class="button-group">
        <a href="add_faculty.php" class="action-button">Add Faculty</a>
        <a href="assign_course.php" class="action-button">Assign Course</a>
      </div>
    </div>

    <!-- View Box -->
    <div class="box">
      <h2>View Reports</h2>
      <div class="button-group">
        <a href="view_faculty.php" class="view-button">View Faculty with Departments</a>
        <a href="view_workload.php" class="view-button">View Faculty Course Load</a>
      </div>
    </div>
  </div>
</body>
</html>
