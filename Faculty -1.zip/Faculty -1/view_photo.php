<?php
$connection = pg_connect("host=localhost dbname=faculty user=postgres password=1234");
$id = $_GET['id'];

$query = "SELECT photo_data FROM faculty WHERE id = $id";
$result = pg_query($connection, $query);
$row = pg_fetch_assoc($result);

if ($row && $row['photo_data']) {
    header("Content-Type: image/jpeg");
    echo pg_unescape_bytea($row['photo_data']);
} else {
    echo "No photo found.";
}
?>
