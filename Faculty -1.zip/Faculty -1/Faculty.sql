-- Create table for departments
CREATE TABLE department (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

-- Create table for faculty
CREATE TABLE faculty (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    doj DATE NOT NULL,
    department_id INT REFERENCES department(id) ON DELETE SET NULL,
    photo_data BYTEA
);

-- Create table for courses
CREATE TABLE course (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL
);

-- Create mapping table for faculty-course assignments
CREATE TABLE faculty_course (
    id SERIAL PRIMARY KEY,
    faculty_id INT REFERENCES faculty(id) ON DELETE CASCADE,
    course_id INT REFERENCES course(id) ON DELETE CASCADE,
    semester VARCHAR(10) NOT NULL
);

-- Create table for login credentials
CREATE TABLE login (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL
);

-- Stored procedure to assign course to faculty
CREATE OR REPLACE PROCEDURE assign_course_to_faculty(
    p_faculty_id INT,
    p_course_id INT,
    p_semester VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO faculty_course (faculty_id, course_id, semester)
    VALUES (p_faculty_id, p_course_id, p_semester);
END;
$$;

-- Sample departments
INSERT INTO department (name) VALUES 
('Computer Science'), 
('Electronics and Communication'), 
('Mechanical Engineering');

-- Sample courses
INSERT INTO course (name, code) VALUES 
('Data Structures', 'CS201'), 
('Digital Circuits', 'EC202'), 
('Thermodynamics', 'ME203');

-- Sample login users
INSERT INTO login (username, password, role) VALUES 
('admin', 'admin123', 'admin'), 
('faculty1', 'pass123', 'faculty');
