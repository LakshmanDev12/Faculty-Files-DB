<?php
$connection = pg_connect("host=localhost dbname=faculty user=postgres password=1234");
if (!$connection) {
    die("Connection failed.");
}
?>
