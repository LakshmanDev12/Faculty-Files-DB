<?php
// Connect to PostgreSQL
$connection = pg_connect("host=localhost dbname=faculty user=postgres password=1234");
session_start();

$msg = "";

if (isset($_POST['submit'])) {
    $username = pg_escape_string($connection, $_POST['username']);
    $password = pg_escape_string($connection, $_POST['password']);

    $query = "SELECT * FROM login WHERE username='$username' AND password='$password'";
    $result = pg_query($connection, $query);

    if (pg_num_rows($result) > 0) {
        $row = pg_fetch_assoc($result);

        $_SESSION['USERID'] = $row['id'];
        $_SESSION['USERNAME'] = $row['username'];
        $_SESSION['USERROLE'] = $row['role'];
        $userole = $row['role'];

        if ($userole == 'asdf' || $userole == 'asdf') {
            header("Location: home.php");
            exit();
        }
    } else {
        $msg = "Please Enter Valid Details !";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - PSG College Of Technology</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
   
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Inter', sans-serif;
    }

    body {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* A warm gradient */
  min-height: 100vh;

  justify-content: center;
 
  padding: 40px;
}

    .container {
      display: flex;
      width: 90%;
      max-width: 1000px;
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .left-panel {
      flex: 1;
      background: url('https://images.unsplash.com/photo-1517520287167-4bbf64a00d66?auto=format&fit=crop&w=800&q=80') no-repeat center center;
      background-size: cover;
    }

    .right-panel {
      flex: 1;
      padding: 40px;
      background: #fff;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
      background-image: url('https://www.transparenttextures.com/patterns/asfalt-light.png');
    }

    .right-panel img {
      width: 60px;
      margin: 0 auto 10px;
    }

    .right-panel h2 {
      text-align: center;
      font-weight: 700;
      font-size: 22px;
      margin-bottom: 10px;
    }

    .right-panel h3 {
      text-align: center;
      margin-top: 20px;
      margin-bottom: 5px;
      font-size: 18px;
    }

    .right-panel p {
      text-align: center;
      color: #555;
      font-size: 14px;
      margin-bottom: 30px;
    }

    .error-msg {
      color: red;
      text-align: center;
      margin-bottom: 15px;
      font-size: 14px;
    }

    form {
      width: 100%;
    }

    label {
      font-weight: 600;
      margin-bottom: 8px;
      display: block;
      font-size: 14px;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #3366ff;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      font-weight: 600;
    }

    button:hover {
      background-color: #2b55e7;
    }

    .link {
      margin-top: 15px;
      text-align: center;
    }

    .link a {
      text-decoration: none;
      color: #3366ff;
      font-size: 14px;
    }

    .chat-icon {
      position: absolute;
      bottom: 20px;
      right: 20px;
      display: flex;
      gap: 10px;
    }

    .chat-icon img {
      width: 35px;
      height: 35px;
    }

    @media (max-width: 768px) {
      .container {
        flex-direction: column;
      }

      .left-panel {
        height: 200px;
      }
    }
  </style>
</head>
<body>
  <br> <br> <br> 
  <center>
  <h2>Integrated Faculty Management Portal</h2><br>
 
  <div class="container">
    <div class="left-panel"></div>
    <div class="right-panel">
      <img src="https://upload.wikimedia.org/wikipedia/en/5/54/PSG_College_of_Technology_logo.png" alt="PSG Logo"/>
      <h2>PSG College Of Technology</h2>
      <h3>Sign In</h3>


      <?php if (!empty($msg)): ?>
        <div class="error-msg"><?php echo $msg; ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" placeholder="Enter your username" required />

        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password" required />

        <button type="submit" name="submit">Login</button>
      </form>

     

      <div class="chat-icon">
        <img src="https://img.icons8.com/ios-filled/50/000000/chat.png" alt="Chat">
        <img src="https://img.icons8.com/fluency/48/brain.png" alt="Brain">
      </div>
    </div>
  </div>
  </center>
</body>
</html>
