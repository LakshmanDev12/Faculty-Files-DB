<?php include('database.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assign Course</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
    }
    body {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* A warm gradient */
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
}

    .form-container {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 500px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 26px;
      color: #333;
    }

    label {
      font-weight: 600;
      display: block;
      margin-bottom: 8px;
      margin-top: 16px;
    }

    input[type="number"],
    input[type="text"] {
      width: 100%;
      padding: 12px;
      margin-top: 4px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    input[type="submit"] {
      margin-top: 24px;
      width: 100%;
      background-color: #3366ff;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #2b55e7;
    }

    p {
      text-align: center;
      margin-top: 20px;
      font-size: 16px;
      color: green;
    }

    .error {
      color: red;
    }

    @media (max-width: 600px) {
      .form-container {
        padding: 25px;
      }
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>Assign Course to Faculty</h2>
  <form method="post">
    <label for="faculty_id">Faculty ID</label>
    <input type="number" id="faculty_id" name="faculty_id" required>

    <label for="course_id">Course ID</label>
    <input type="number" id="course_id" name="course_id" required>

    <label for="semester">Semester</label>
    <input type="text" id="semester" name="semester" required>

    <input type="submit" name="submit" value="Assign">
  </form>

  <?php
  if (isset($_POST['submit'])) {
      $fid = $_POST['faculty_id'];
      $cid = $_POST['course_id'];
      $sem = $_POST['semester'];

      $query = "CALL assign_course_to_faculty($fid, $cid, '$sem')";
      $result = pg_query($connection, $query);

      if ($result) {
          echo "<p>Course assigned successfully.</p>";
      } else {
          echo "<p class='error'>Error assigning course: " . pg_last_error($connection) . "</p>";
      }
  }
  ?>
</div>

</body>
</html>
