<?php
// PostgreSQL DB connection
$connection = pg_connect("host=localhost dbname=faculty user=postgres password=1234");

if (!$connection) {
    die("Connection failed: " . pg_last_error());
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $doj = $_POST['doj'];
    $department_id = $_POST['department_id'];

    if (isset($_FILES['photo']) && $_FILES['photo']['type'] === 'image/jpeg') {
        $photo_data = file_get_contents($_FILES['photo']['tmp_name']);
        $escaped_photo = pg_escape_bytea($photo_data);

        $query = "INSERT INTO faculty (name, doj, department_id, photo_data)
                  VALUES ('$name', '$doj', $department_id, '{$escaped_photo}')";

        $result = pg_query($connection, $query);

        if ($result) {
            echo "<p style='color: green; text-align:center;'>Faculty added successfully with photo!</p>";
        } else {
            echo "<p style='color: red; text-align:center;'>Error: " . pg_last_error($connection) . "</p>";
        }
    } else {
        echo "<p style='color: red; text-align:center;'>Please upload a valid .jpg image.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Faculty</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
    }

    body {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* A warm gradient */
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px;
}


    .form-container {
      background: #fff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 500px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 26px;
      color: #333;
    }

    label {
      font-weight: 600;
      display: block;
      margin-bottom: 8px;
      margin-top: 16px;
    }

    input[type="text"],
    input[type="number"],
    input[type="date"],
    input[type="file"] {
      width: 100%;
      padding: 12px;
      margin-top: 4px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    input[type="submit"] {
      margin-top: 24px;
      width: 100%;
      background-color: #3366ff;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #2b55e7;
    }

    p {
      margin-top: 20px;
      font-size: 16px;
    }

    @media (max-width: 600px) {
      .form-container {
        padding: 25px;
      }
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>Add New Faculty</h2>
  <form action="add_faculty.php" method="POST" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Department ID:</label>
    <input type="number" name="department_id" required>

    <label>Date of Joining:</label>
    <input type="date" name="doj" required>

    <label>Upload Photo (JPG):</label>
    <input type="file" name="photo" accept=".jpg" required>

    <input type="submit" name="submit" value="Add Faculty">
  </form>
</div>

</body>
</html>
